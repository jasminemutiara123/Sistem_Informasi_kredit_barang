# from django.urls import path
# from . import views

# app_name = 'api'

# urlpatterns = [
#     path('', views.index, name='index'),  # untuk tes hello world
#     path('tablepembayaran/', views.TablepembayaranListAPIView.as_view(), name='tablepembayaran-list'),  # untuk API Tablepembayaran
#     path('tablepembayaran/', views.TablepembayaranListAPIView.as_view(), name='table_pembayaran_list'),
# ]

from django.urls import path
from api.views import TablepembayaranAPI 
from api.views import TablepembayaranDetailApiView

urlpatterns = [
    path('api/table-pembayaran/', TablepembayaranAPI.as_view(), name='table-pembayaran-api'),
] 
urlpatterns = [
    path('api/table-pembayaran/<int:id>/', TablepembayaranDetailApiView.as_view(), name='table-pembayaran-api'),
    
]