from django.contrib import admin
from pos_app.models import User, Tablepembayaran

admin.site.register(User)
admin.site.register(Tablepembayaran)
