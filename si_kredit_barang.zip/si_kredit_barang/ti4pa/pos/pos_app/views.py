from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from pos_app.models import Tablepembayaran
from api.serializers import TablepembayaranSerializer

class TablepembayaranListAPIView(APIView):
    def get(self, request, *args, **kwargs):
        table_pembayarans = Tablepembayaran.objects.all()
        serializer = TablepembayaranSerializer(table_pembayarans, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        data = {
            'id': request.data.get('id'),
            'tanggal_pembayaran': request.data.get('tanggal_pembayaran'),
            'keterangan': request.data.get('keterangan'),
        }
        serializer = TablepembayaranSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            response = {
                'status': status.HTTP_201_CREATED,
                'message': 'Data created successfully...',
                'data': serializer.data
            }
            return Response(response, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# untuk tes hello world
from django.http import HttpResponse

def index(request):
    return HttpResponse("Hello from pos_app!")
