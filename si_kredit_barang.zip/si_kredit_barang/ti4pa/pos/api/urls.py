from django.urls import path, include
from api import views
from rest_framework.urlpatterns import format_suffix_patterns
from .views import (
  TablePembayaranDetailApiView, TablePembayaranListCreateApiView
  
)

app_name = 'api'

urlpatterns = [

    path('table-Pembayaran/', views.TablePembayaranListCreateApiView.as_view(), name='table-Pembayaran-list'),
    path('table-Pembayaran/<int:id>/', views.TablePembayaranDetailApiView.as_view(), name='table-Pembayaran-detail'),
]
