from rest_framework import serializers
from pos_app.models import (
    User, TablePembayaran
)
from rest_framework import serializers
from pos_app.models import (
    User, StatusModel, Profile, TablePembayaran, Category, Menupembayaran, OrderMenu, OrderMenuDetail,
)
from django.contrib.auth import authenticate
from rest_framework.validators import UniqueValidator
from django.core.exceptions import ValidationError
from django.contrib.auth.password_validation import validate_password

class TablepembayaranSerializer(serializers.ModelSerializer):
    class Meta:
        model = TablePembayaran
        fields = ('id', 'tanggal_pembayaran', 'keterangan', 'table_status', 'status')
class RegisterUserSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=True,
        validators=[UniqueValidator(queryset=User.objects.all())])
    password1 = serializers.CharField(write_only=True,
        required=True, validators=[validate_password])
    password2 = serializers.CharField(write_only=True,
        required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2',
                  'is_active', 'is_pelanggan', 'first_name', 'last_name']
        extra_kwargs = {
            'first_name': {'required': True},
            'last_name': {'required': True}
        }

    def validate(self, attrs):
        if attrs['password1'] != attrs['password2']:
            raise serializers.ValidationError({
                'password': 'Kata sandi dan Ulang kata sandi tidak sama...'
            })
        return attrs
    def create(self, validated_data):
        user = User.objects.create(
        username = validated_data['username'],
        email = validated_data['email'],
        is_active = validated_data['is_active'],
        is_pembayaran = validated_data['is_pembayaran'],
        first_name = validated_data['first_name'],
        last_name = validated_data['last_name']
        )
        user.set_password(validated_data['password1'])
        user.save()
        return user
